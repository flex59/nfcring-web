*********************************************************************
---------------------------------------------------------------------
NFC Ring Custom Inlay Cover Design Guide
---------------------------------------------------------------------
*********************************************************************

This is intended as a general guide to help ensure you supply 
your design in the correct format for our printer to work with.
If you don't know what you are doing - it's probably worth pulling 
a favour from a print design buddy to help advise you.




Template Guide (Color refs relate to associated files)
*********************************************************************

Safe Zone (Darker Green): 4mm Width x 20mm Length
Full Inlay (Light Green): 6mm Width x 22mm Length
Print Bleed (Red):				10mm Width x 26m Length


Safe Zone (Darker Green)
---------------------------------------------------------------------

Try to keep any important detail of your design within this area.
Due to the nature of the printing and cutting process, there is a 
possibility that the inlays will be trimmed ever so slightly off 
from the absolute edge. Therefore, it is much safer to keep any 
important details of your design is kept a away from it.


Full Inlay (Light Green)
---------------------------------------------------------------------

The light green color shows the overall dimensions of the final
inlay cover. In absolutely no circumstances should your design 
go over this line - unless it is included in the bleed. (see below).


Print Bleed (Red)
---------------------------------------------------------------------

The outer red color in the documents signify the 'print bleed' area.
This area is included if you have a design that fills any part of the 
inlay cover, from edge to edge. For example - perhaps you have a 
repeating pattern across your inlay cover. In this scenario, you 
should repeat your pattern over the edge of the Full Inlay, into 
the print bleed - rather than cutting it straight at the edge.

This ensure that any minor movement in the cutting process does not
leave any exposed areas of your design unfinished. please utilise 
this area if you have patterns or colors that are intended to run 
right up to the side of the inlay cover.



Typography
*********************************************************************

We are working with an extremely small surface area here. Very small 
sized type will not print very well and may not remain legible.
Please keep any type sizes no less than 8pt at the very minimum.
If you use fonts in your design. DON'T FORGET TO OUTLINE THEM!



Color Values
*********************************************************************

Please keep your colors to CMYK colorspace. Any document supplied in 
RGB will be converted, which may result in slightly less vibrant looking 
appearance.



Imagery/Photographs
*********************************************************************

Again, we are working with a very small surface area here. You *could*
send us a photo to put on the ring, but we can't guarantee that every 
detail will be visible. If you are sure you want a photo on there, 
please crop the photo to fit the bleed size (10mm x 26mm) and send at
the highest resolution you can.



File Formats
*********************************************************************

Please make use of template files we have supplied in this package.
If you are working with vectors - use the .ai, or .eps files.
If you are working with a photo, or non-vector based graphic, please
send us a non-compressed JPEG or TIFF file at a minimum of 300dpi.


Any questions - drop us an email at custom@nfcring.com




TL;DR - Vectors are your friend. Please don't send us shitty quality 
artwork and expect us to make it look awesome on your ring. There is 
no ENHANCE button here ;)


